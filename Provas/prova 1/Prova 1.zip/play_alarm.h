//Funcao de alarme

#ifndef ALARME_H  	//If not defined ...
#define ALARME_H	//define
void play_alarm_music( char *estado);
#endif
